import React from "react";
// import { NavLink } from "react-router-dom";



const Cards=(props)=>{
  return(
        <div className="container-fluid">
            <div class="card-deck">
                <div class="card h-100">
                    <img className="card-img-top" src= {props.image} alt="Card image cap"/>
                    <div className="card-body text-center">
                        <h5 className="card-title">{props.title}</h5>
                        <p className="card-text">{props.text}</p>
                        <a href={props.links}>
                            <button className="btn btn-outline-success">Check Out</button> 
                        </a>
                    </div>
                </div>
            </div>
        </div>
  )

}
export default Cards