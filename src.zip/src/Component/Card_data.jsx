
const Card_data =
[
    {
        image:"/image/payment.jpg",
        title: "Online Processing Engine",
        text: "Our proprietary payment gateway provides seamless processing with maximum uptime capabilities.",
        links: "https://openacquiring.com/online-processing-engine/",
    },
    {
        image:"/image/payment.jpg",
        title: "E-invoicing",
        text: "Streamline your billing process online and eliminate wasteful paper invoices. Send your custom invoice without the cost of postage and no longer wait for the mail to get paid.",
        links: "https://openacquiring.com/e-invoicing/",
    },
    {
        image:"/image/payment.jpg",
        title: "Risk Engine",
        text: "Helps to detect, analyze and manage transaction, behavior and habits of the merchants and the cardholders based on a number of pre-defined monitoring rules in the system. ",
        links : "https://openacquiring.com/risk-engine/",
    },
    {
        image:"/image/payment.jpg",
        title: "Chargeback Management Engine",
        text: "Reduce the time and effort it takes to respond to chargebacks and retrieval requests with our  Chargeback Management Engine.",
        links: "https://openacquiring.com/charge-back/",
    },
    {
        image:"/image/payment.jpg",
        title: "Robust Analytics and Reporting",
        text: "Captures the data bundled with transaction requests and portrays them into meaningful analytics. ",
        links : "https://openacquiring.com/analytics-and-reporting/",
    },
    {
        image:"/image/payment.jpg",
        title: "Recurring Engine",
        text: "Charge your customers with one-off invoicesor automatically on a recurring basis. ",
        links : "https://openacquiring.com/recurring-engine/",
    },
];
export default Card_data