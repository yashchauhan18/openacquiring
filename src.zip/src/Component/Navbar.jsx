import React from "react";
import { NavLink } from "react-router-dom";



const Navbar = () => {
    return (
        <>
            <div className="container-fluid nav_bg">
                <div className="row">
                    <div className="col-12 mx-auto">
                    <nav className="navbar navbar-expand-lg navbar-light">
                     <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                         <span className="navbar-toggler-icon"></span>
                     </button>
                     <div className="collapse navbar-collapse" id="navbarTogglerDemo01">
                         <div className="col-md-3">
                            <a className="navbar-brand" to ="/"> <img src="/image/logo.png" alt="openacquiring" style={{height:"60px",width:"90%"}}/> </a>
                         </div>
                         <div className="col-md-9">
                            <ul className="float-md-right navbar-nav ml-auto mt-2 mt-lg-0">
                                <li className="nav-item active">
                                    <NavLink className="nav-link" to="/Home">Home <span className="sr-only">(current)</span></NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="/About">About Us</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="/Solution">Our Solution</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="/Merchant_Form">Online Merchant Form</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="#">Developer Corner</NavLink>
                                </li>
                                <li className="nav-item">
                                    <NavLink className="nav-link" to="/Contact">Contact us</NavLink>
                                </li>
                            </ul>
                       </div>
                   </div>
                 </nav>
                        
                    </div>
                </div>
            </div>
        </>    
               
    )
}

export default Navbar
