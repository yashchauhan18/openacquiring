import React from "react";
import { NavLink } from "react-router-dom";
// import { Button } from "react-bootstrap/Button";
const About=()=>
{
    return(
        <>
            <section className="d-flex align-items-center">
                <div  className="container-fluid nav_bg">
                    <div className="row">
                        <div className="col-10 mx-auto">
                            <h1 className="intro">Who We Are</h1>
                            <div className="row about_detail">
                                <div className="col-md-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex justify-content-center flex-column">
                                    <h1>Empower your Online Business</h1>
                                    <p>Our in-house proprietary gateway provides seamless checkout experience. 
                                        Innovation is at the heart of our DNA. Our innovative approach to our gateway
                                        conception and the services we offer makes transactions faster, seamless and
                                        more convenient and secure. With pioneering solutions like Investigate 360, 
                                        Risk Engine, e-invoicing, Powerful analytics, Chargeback Management Engine 
                                        and automated statement; we enable merchants/PSP/Financial Institution to 
                                        stay ahead of the competition and give consumers the flexibility they need. 
                                    </p>
                                    <div className="mt-3">
                                       <NavLink to="/About" className="btn btn-outline-success" >Read More</NavLink>
                                    </div>
                                </div>
                                <div className="col-md-6 pt-5 pt-lg-0 order-2 order-lg-1">
                                    <img src="/image/payment.jpg" className="img-fluid animated" alt="payment" width="600" height="500"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
}
export default About