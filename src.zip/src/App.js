import React from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.bundle";
import Home from "./Page/Home";
import { Redirect, Route, Switch } from 'react-router-dom';
import About from "./Page/About";
import Solution from "./Page/Solution";
import Developer from "./Page/Developer";
import Onile_Merchant_Form from "./Page/Online_Merchant_Form";
import Contact from "./Page/Contact";
import Merchant_Form from "./Page/Merchant_Form";
// import Navbar from "./Component/Navbar";

const App=()=>
{
  return(
    <>
    {/* <Navbar /> */}
    <Switch>
      <Route exact path="/" component={Home} />
      <Route exact path="/About" component={About} />
      <Route exact path="/Solution" component={Solution} />
      <Route exact path= "/Developer" component={Developer} />
      <Route exact path="/Onile_Merchant_Form" component={Onile_Merchant_Form} />
      <Route exact path="/Merchant_Form" component={Merchant_Form} />
      <Route exact path="/Contact" component={Contact} />
      <Redirect to ="/"/>
    </Switch>
    </>
  );
}
export default App;
