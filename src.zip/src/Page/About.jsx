import React from 'react';
import { NavLink } from 'react-router-dom';
import Navbar from "../Component/Navbar";
import Footer from "../Page/Footer";

function About() {

    return (
       <>
       <Navbar/>
        <section className="page-title-light breadcrumb_section parallax_bg overlay_bg_50" > 
            <div className="container-fluid">
                <div className="row align-items-center breadimage" >
                    <div class="col-sm-6">
                        <div class="page-title">
                            <h1>About Us</h1>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-sm-end">
                            <li class="breadcrumb-item"><NavLink className="nav_link"to="/Home">Home</NavLink></li>
                            <li class="breadcrumb-item active" aria-current="page">About Us</li>
                        </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <section className="about_us" style={{backgroundColor: "#F2F3F4", margin:"2%"}}>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-12 mx-auto">
                        <div className="row">
                            <div class="col-md-6">
                                <p>Founded by a group of visionary fintech professionals, Open Acquiring is a robust and secure online B2B payment solution provider that enables businesses to process transactions online through our own proprietary technology suited for the current market. Our engine boast the capacity of processing Open Acquiring caters to growing small and medium enterprises, large corporations and the e-commerce market by empowering them with a range of comprehensive payment solutions. OPAC guarantees the best solutions as a payment gateway provider for merchants that connects online companies from all over the world.
                                    <br/>
                                    Our Executive team have more than 15 years of experience in payments and brings deep industry knowledge, diverse experience and a firm commitment to guiding the company and clients toward strategic goals. <br/>
                                    With simple and fast integration, you can accept card payment and more than 20 local payment methods, have a full data analysis of their transactions, and our robust Risk engine to prevent fraudulent transactions. We are a PCI DSS Compliant Service Provider with the highest level of PCI DSS accreditation (Level 1). 
                                </p>
                            </div>
                            <div class="col-md-6">
                                <img src="/image/payment.jpg" className="img-fluid"></img>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <Footer/>

       </>
    )
}
export default About;
