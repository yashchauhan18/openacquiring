import React from 'react'

function Developer() {
    return (
        <div>
            <h1>Welcoe To Developer</h1>
        </div>
    )
}

export default Developer
