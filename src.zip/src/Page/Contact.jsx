import React from "react";
import Navbar from "../Component/Navbar";
import { NavLink } from 'react-router-dom';
import Footer from "../Page/Footer";


const Contact=()=>{
    return(
            <>
             <Navbar/>
                <section className="page-title-light breadcrumb_section parallax_bg overlay_bg_50" > 
                    <div className="container-fluid">
                        <div className="row align-items-center breadimage" >
                            <div class="col-sm-6">
                                <div class="page-title">
                                    <h1>Contact Us</h1>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <nav aria-label="breadcrumb">
                                <ol class="breadcrumb justify-content-sm-end">
                                    <li class="breadcrumb-item"><NavLink className="nav_link" to="/Home">Home</NavLink></li>
                                    <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                                </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </section>
                <div class="thm-container">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="contact-form-content">
                                <div class="title">
                                    <span>Contact with us</span>
                                    <h2>Send Message</h2>
                                </div>
                                <form action="inc/sendemail.php" class="contact-form" novalidate="novalidate">
                                    <input type="text" name="name" placeholder="Your full name" />
                                    <input type="text" name="email" placeholder="Your email address" />
                                    <textarea name="message" placeholder="What you are looking for?"></textarea>
                                    <button type="submit" class="thm-btn yellow-bg">Submit Now</button>
                                    <div class="form-result"></div>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="contact-info text-center">
                                <div class="title text-center">
                                    <span>Contact info</span>
                                    <h2>Details</h2>
                                </div>
                                <div class="single-contact-info">
                                    <h4>Address</h4>
                                    <p>xyz</p>
                                </div>
                                <div class="single-contact-info">
                                    <h4>Phone</h4>
                                    <p>Local: +971 58 575 9891 <br/> Mobile: +971 58 575 9891</p>
                                </div>
                                <div class="single-contact-info">
                                    <h4>Email</h4>
                                    <p>info@openacquiring.com <br/> info@openacquiring.com</p>
                                </div>
                                <div class="single-contact-info">
                                    <h4>Follow</h4>
                                    <div class="social">
                                        <a href="#" class="fab fa-twitter hvr-pulse"></a>
                                        <a href="#" class="fab fa-pinterest hvr-pulse"></a>
                                        <a href="#" class="fab fa-facebook-f hvr-pulse"></a>
                                        <a href="#" class="fab fa-youtube hvr-pulse"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <Footer/>
            </>
    );
}
export default Contact;