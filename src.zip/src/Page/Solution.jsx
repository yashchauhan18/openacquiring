import React from 'react';
import { NavLink } from 'react-router-dom';
import Navbar from "../Component/Navbar";
import Footer from "../Page/Footer";
import Cards from "../Component/Cards";
import Card_data from "../Component/Card_data";

function Solution() {
    return (
        <>
         <Navbar/>
        <section className="page-title-light breadcrumb_section parallax_bg overlay_bg_50" > 
            <div className="container-fluid">
                <div className="row align-items-center breadimage" >
                    <div class="col-sm-6">
                        <div class="page-title">
                            <h1>Our Solution</h1>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-sm-end">
                            <li class="breadcrumb-item"><NavLink className="nav_link"to="/Home">Home</NavLink></li>
                            <li class="breadcrumb-item active" aria-current="page">Our Solution</li>
                        </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </section>
        <section className="solution" style={{backgroundColor: "#F2F3F4", margin:"2%"}}>
            <div className="container-fluid d-flex justify-content-center">
                <div className="row">
                    <div className="col-12 mx-auto">
                            <div className="row">
                                <div className="col-md-4">
                                    <Cards
                                        image={Card_data[0].image} 
                                        title={Card_data[0].title}
                                        text={Card_data[0].text}
                                        links={Card_data[0].links} />
                                </div>
                                <div className="col-md-4">
                                    <Cards
                                        image={Card_data[1].image}
                                        title={Card_data[1].title}
                                        text={Card_data[1].text}
                                        links={Card_data[1].links}
                                        />
                                </div>
                                <div className="col-md-4">
                                    <Cards
                                        image={Card_data[2].image}
                                        title={Card_data[2].title}
                                        text={Card_data[2].text}
                                        links={Card_data[2].links}
                                    />
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-4">
                                    <Cards
                                        image={Card_data[3].image}
                                        title={Card_data[3].title}
                                        text={Card_data[3].text} 
                                        links={Card_data[3].links}
                                        />
                                       
                                </div>
                                <div className="col-md-4">
                                    <Cards
                                        image={Card_data[4].image}
                                        title={Card_data[4].title}
                                        text={Card_data[4].text}
                                        links={Card_data[4].links}
                                        />
                                </div>
                                <div className="col-md-4">
                                    <Cards
                                        image={Card_data[5].image}
                                        title={Card_data[5].title}
                                        text={Card_data[5].text}
                                        links={Card_data[5].links}
                                    />
                                </div>
                            </div>
                        
                    </div>

                </div>
            </div>
        </section>

        <section className="d-flex align-items-center">
                <div  className="container-fluid nav_bg pay">
                    <div className="row">
                        <div className="col-11 mx-auto">
                            <h1 className="intro">Payment Solutions</h1>
                            <div className="row about_detail">
                                <div className="col-md-6 pt-5 pt-lg-0 order-2 order-lg-1 d-flex justify-content-center flex-column">
                                    <p className="payment_solution">Our in-house state of Art Technology guarantees optimum processing and smart routing. Our Analytics tool as well as the automated onboarding system and upcoming of e-invoicing make us stand apart.<br/>

                                        Why pay higher fees that should be part of a standard service? Integrating Open Acquiring into your website and/or payment application will give your business the competitive edge that it needs to process payments in a robust and fully secure platform that is trusted by 10,000+ merchants. Our in-house payments experts have consulted thousands of merchants from small businesses through to the biggest organisations around. We are ready to advise you on the right payment solutions for your company.<br/>

                                        Whether you’re looking to bill customers on a periodic basis, set up a marketplace, or only accept payments, organize it all with a fully integrated, global platform that can support online payments.
                                    </p>
                                    <div className="mt-3" style={{margin:"2%"}} >
                                       {/* <NavLink to="/About" className="btn btn-outline-success" >Read More</NavLink> */}
                                    </div>
                                </div>
                                <div className="col-md-6 pt-5 pt-lg-0 order-2 order-lg-1">
                                    <img src="/image/payment.jpg" className="img-fluid animated" alt="payment" width="600" height="500"/>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        <Footer/>
        </>
    )
}

export default Solution
