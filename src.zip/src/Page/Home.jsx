import React from "react";
import Navbar from "../Component/Navbar";
import Slider from "../Component/Slider";
import About from "../Component/About";
import Cards from "../Component/Cards";
import Footer from "../Page/Footer";
import Card_data from "../Component/Card_data";

const Home=()=>
{
    return(
        <>
            <Navbar/>
            <Slider/>
            <About/>
            <h2 className="text-center">Our Services</h2>
            <div className="container-fluid d-flex justify-content-center">
                <div className="row">
                    <div className="col-md-4">
                        <Cards
                            image={Card_data[0].image}
                            title={Card_data[0].title}
                            text={Card_data[0].text} />
                    </div>
                    <div className="col-md-4">
                        <Cards
                            image={Card_data[1].image}
                            title={Card_data[1].title}
                            text={Card_data[1].text}
                            />
                    </div>
                    <div className="col-md-4">
                        <Cards
                            image={Card_data[2].image}
                            title={Card_data[2].title}
                            text={Card_data[2].text}
                        />
                    </div>
                </div>
            </div>
            <Footer/>
        </>
    );
}
export default Home;