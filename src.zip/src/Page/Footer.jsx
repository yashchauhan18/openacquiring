import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheckSquare, faCoffee } from '@fortawesome/fontawesome-free-solid';
import '@fortawesome/fontawesome-free/css/all.min.css';

const Footer=()=>
{
    return(
        <section className="footer1">
                <footer class="footer">
                <div class="container bottom_border">
                <div class="row">
                    <div class=" col-sm-4 col-md col-sm-4  col-12 col">
                    <h5 class="headin5_amrc col_white_amrc pt2">Find us</h5>
            
                    <p class="mb10">Founded by a group of visionary fintech professionals, Open Acquiring is a robust and secure online B2B payment solution provider that enables businesses to process transactions online through our own proprietary technology suited for the current market.</p>
                    <p><i class="fa fa-location-arrow"></i>xyz </p>
                    <p><i class="fa fa-phone"></i>  +971 58 575 9891  </p>
                    <p><i class="fa fa fa-envelope"></i> info@openacquiring.com </p>
                    </div>


                <div class=" col-sm-4 col-md  col-6 col">
                <h5 class="headin5_amrc col_white_amrc pt2">Quick links</h5>
           
                    <ul class="footer_ul_amrc">
                        <li><a href="http://webenlance.com">Online Processing Engine</a></li>
                        <li><a href="http://webenlance.com">E-invoicing</a></li>
                        <li><a href="http://webenlance.com">Risk Engine</a></li>
                        <li><a href="http://webenlance.com">Chargeback Management Engine</a></li>
                        <li><a href="http://webenlance.com">Robust Analytics and Reporting</a></li>
                        <li><a href="http://webenlance.com">Recurring Engine</a></li>
                    </ul>
                </div>
                <div class=" col-sm-4 col-md  col-6 col">
                <h5 class="headin5_amrc col_white_amrc pt2">Quick links</h5>
            
                <ul class="footer_ul_amrc">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Solution</a></li>
                    <li><a href="#">Developer</a></li>
                    <li><a href="#">Online Merchant Form</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
                </div>
                <div class=" col-sm-4 col-md  col-12 col">
                    <h5 class="headin5_amrc col_white_amrc pt2">Follow us</h5>
                    <FontAwesomeIcon icon={faCoffee}/>
                    <FontAwesomeIcon icon={faCheckSquare}/>
                    <ul class="footer_ul2_amrc">
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
                </div>
                </div>


                <div class="container">
                {/* <ul class="foote_bottom_ul_amrc">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Our Solution</a></li>
                    <li><a href="#">Developer</a></li>
                    <li><a href="#">Online Merchant Form</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
                 */}
                <p class="text-center">Copyright @2021 | Designed With by <a href="#">Doozycod System</a></p>
                <ul class="social_footer_ul">
                    <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                </ul>
                </div>
            </footer>
        </section>
    );
}
export default Footer
