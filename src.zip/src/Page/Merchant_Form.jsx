import React from "react";
import Navbar from "../Component/Navbar";
// import { NavLink } from 'react-router-dom';
import Footer from "../Page/Footer";

const Merchant_Form = () =>
{
    // const [legalName, setLegalName]= useState("");
    // const[tradingName,setTradingName]= useState("");
    // const[previousName,setPreviousName]= useState("");
    // const[companyRegistrationNumber,setCompanyRegistrationNumber]= useState("");
    // const[yearOfIncorporation,setYearOfIncorporation]= useState("");


const inputEvent=(event) =>
{
   alert(event.target.value);
    // event.target.value;

}
    
const onSubmits=(event)=>
{
    alert("hello");
    event.preventDefault();
    let formData= new FormData();
    formData.append("text",);
}  
    return(
        <>
        <Navbar/>
        <section className="merchant d-flex align-items-center btn-outline-info">
                <div className="container-fluid">
                    <div className="row">
                            <form style={{margintop:"20px"}}>
                            <h2 className="text-center m-4 "> Merchant Application Form</h2>
                                <div className="col-11 mx-auto">
                                <div className="form-row">
                                        <div className="form-group col-md-4">
                                            <label for="legal">Legal Comapany Name</label>
                                            <input type="text" className="form-control" onChange = {inputEvent} placeholder="Legal Comapany Name" />
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="trading">Trading Name</label>
                                            <input type="text" className="form-control" onChange = {inputEvent}  placeholder="Trading Name" />
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="Previous name(s) if applicable">Previous name(s) if applicable</label>
                                            <input type="text" className="form-control" onChange = {inputEvent}  placeholder="Previous name(s) if applicable" />
                                        </div>
                                    </div>
                                    <div className="form-row">
                                        <div className="form-group col-md-6">
                                            <label for="Company registration number">Company registration number</label>
                                            <input type="text" className="form-control" onChange = {inputEvent}  placeholder="Company registration numbe" />
                                        </div>
                                        <div className="form-group col-md-6">
                                            <label for="Year of incorporation">Year of incorporation</label>
                                            <input type="text" className="form-control" onChange = {inputEvent} placeholder="Year of incorporation" />
                                        </div>
                                    </div>

                                    <div className="form-group">
                                        <label for="inputAddress">Address</label>
                                        <input type="text" className="form-control" id="inputAddress" onChange = {inputEvent} placeholder="Address" />
                                    </div>

                                    <div className="form-row">
                                        <div className="form-group col-md-4">
                                            <label for="inputCity">Post code</label>
                                            <input type="text" className="form-control" id="inputCity" onChange = {inputEvent} placeholder="Post code"/>
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="inputZip">City </label>
                                            <input type="text" className="form-control" id="inputZip" onChange = {inputEvent} placeholder="City" />
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="inputState">Country</label>
                                            <select id="inputState" className="form-control">
                                                <option selected>Choose...</option>
                                                <option>...</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <label for="typeofbusiness">Type of business</label>
                                        <input type="text" className="form-control" id="inputAddress" onChange = {inputEvent} placeholder="Type of business" />
                                    </div>
                               
                                    <div className="form-group">
                                        <label for="typeofbusiness"> Is your Company/business subject to a trading/business license? If yes, please provide a copy</label><br/>
                                        <div className="form-check-inline">
                                            <label className="form-check-label" for="radio1">
                                                <input type="radio" className="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                            </label>
                                        </div>
                                        <div className="form-check-inline">
                                            <label className="form-check-label" for="radio2">
                                                <input type="radio" className="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                            </label>
                                        </div>
                                    </div>
                                    <div className="form-row">
                                        <div className="form-group col-md-3">
                                            <label for="Currentmonthlysalesvolume">Current monthly sales volume</label>
                                            <input type="text" className="form-control" id="inputCity" onChange = {inputEvent} placeholder="Current monthly sales volume"/>
                                        </div>
                                        <div className="form-group col-md-3">
                                            <label for="Highestticket">Lowest ticket % </label>
                                            <input type="text" className="form-control" id="inputZip" onChange = {inputEvent} placeholder="Lowest ticket" />
                                            <input type="text" className="form-control" id="inputZip" onChange = {inputEvent} placeholder="Lowest ticket" style={{marginTop :"5px"}} />
                                        </div>
                                        <div className="form-group col-md-3">
                                            <label for="inputZip">Highest ticket </label>
                                            <input type="text" className="form-control" id="inputZip" onChange = {inputEvent} placeholder="Highest ticket" />
                                        </div>
                                        <div className="form-group col-md-3">
                                            <label for="Averageticket ">Average ticket </label>
                                            <input type="text" className="form-control" id="inputZip" onChange = {inputEvent} placeholder="Average ticket " />
                                        </div>
                                    </div>

                                    <div className="form-row">
                                        <div className="form-group col-md-4" >
                                            <label for="Currentmonthlysalesvolume">Website URL(s)</label>
                                            <input type="text" className="form-control website" id="website" onChange = {inputEvent} placeholder="Website URL(s)"/>
                                            <input type="text" className="form-control website" id="website" onChange = {inputEvent} placeholder="Website URL(s)"/>
                                            <input type="text" className="form-control website" id="website" onChange = {inputEvent} placeholder="Website URL(s)"/>
                                            <input type="text" className="form-control website" id="website" onChange = {inputEvent} placeholder="Website URL(s)"/>
                                            <input type="text" className="form-control website" id="website" onChange = {inputEvent} placeholder="Website URL(s)"/>
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="Highestticket">Billing descriptor part 1 (max 25 characters) </label>
                                            <input type="text" className="form-control billing" id="inputZip" onChange = {inputEvent} placeholder="Billing descriptor" />
                                            <input type="text" className="form-control billing" id="inputZip" onChange = {inputEvent} placeholder="Billing descriptor" />
                                            <input type="text" className="form-control billing" id="inputZip" onChange = {inputEvent} placeholder="Billing descriptor" />
                                            <input type="text" className="form-control billing" id="inputZip" onChange = {inputEvent} placeholder="Billing descriptor" />
                                            <input type="text" className="form-control billing" id="inputZip" onChange = {inputEvent} placeholder="Billing descriptor" />
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="inputZip">Billing descriptor part 2 (max 13 characters) </label>
                                            <input type="text" className="form-control billing" id="inputZip" onChange = {inputEvent} placeholder="Highest ticket" />
                                            <input type="text" className="form-control billing" id="inputZip" onChange = {inputEvent} placeholder="Highest ticket" />
                                            <input type="text" className="form-control billing" id="inputZip" onChange = {inputEvent} placeholder="Highest ticket" />
                                            <input type="text" className="form-control billing" id="inputZip" onChange = {inputEvent} placeholder="Highest ticket" />
                                            <input type="text" className="form-control billing" id="inputZip" onChange = {inputEvent} placeholder="Highest ticket" />
                                        </div>
                                    </div>
                                    <div className="Bank_Account">
                                        <h3 className="text-center m-4">Merchant Bank Account Information</h3>
                                        <div className="form-row">
                                            <div className="form-group col-md-3">
                                                <label for="Currentmonthlysalesvolume">Bank Name</label>
                                                <input type="text" className="form-control" id="inputCity" onChange = {inputEvent} placeholder="Bank Name"/>
                                            </div>
                                            <div className="form-group col-md-9">
                                                <label for="Highestticket">Registered address </label>
                                                <input type="text" className="form-control" id="inputZip" onChange = {inputEvent} placeholder="Registered address" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-row">
                                        <div className="form-group col-md-4">
                                        <label for="inputCity">Post code</label>
                                        <input type="text" className="form-control" id="inputCity" onChange = {inputEvent} placeholder="Post code"/>
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="inputZip">City </label>
                                            <input type="text" className="form-control" id="inputZip" onChange = {inputEvent} placeholder="City" />
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="inputState">Country</label>
                                            <select id="inputState" onChange = {inputEvent} className="form-control">
                                                <option selected>Choose...</option>
                                                <option>...</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div className="form-row">
                                        <div className="form-group col-md-4">
                                        <label for="inputCity">SWIFT BIC</label>
                                        <input type="text" className="form-control" onChange = {inputEvent} id="inputCity" placeholder="SWIFT BIC"/>
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="inputZip">Account Number </label>
                                            <input type="text" className="form-control" onChange = {inputEvent} id="inputZip" placeholder="Account Number" />
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="inputState">IBAN</label>
                                            <input type="text" className="form-control" onChange = {inputEvent} id="inputZip" placeholder="IBAN" />
                                        </div>
                                    </div>
                                    <div className="form-row">
                                        <div className="form-group col-md-4">
                                        <label for="inputCity">Account Currency</label>
                                        <input type="text" className="form-control" onChange = {inputEvent} id="inputCity" placeholder="Account Currency"/>
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="inputZip">Beneficiary Bank Rounting Number </label>
                                            <input type="text" className="form-control" onChange = {inputEvent} id="inputZip" placeholder="(e.g. Fedwire Number, IFSC)" />
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="inputState"> Local / Domestic Bank Code </label>
                                            <input type="text" className="form-control"  onChange = {inputEvent} id="inputZip" placeholder="(e.g. Sort Code, Branch Code)" />
                                        </div>
                                    </div>
                                    <div className="form-row">
                                        <div className="form-group col-md-4">
                                        <label for="inputCity">E-mail address(es) to receive financial statements</label>
                                        <input type="text" className="form-control" onChange = {inputEvent} id="inputCity" placeholder=""/>
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="inputZip">Beneficiary Bank Rounting Number </label>
                                            <input type="text" className="form-control" onChange = {inputEvent} id="inputZip" placeholder="" />
                                        </div>
                                        <div className="form-group col-md-4">
                                            <label for="inputState">Local / Domestic Bank Code </label>
                                            <input type="text" className="form-control" onChange = {inputEvent} id="inputZip" placeholder="" />
                                        </div>
                                    </div>
                                </div>
                                    
                                <div class="merchant-application">
                                </div>
                                <div className="col-11 mx-auto">
                                <div className="Beneficial">
                                    <strong>Beneficial Owner(s)</strong><p> *Please ensure that all owners with 20% or more of direct or indirect ownership in the applying Company are listed  </p>
                                    <div className="form-row">
                                        <div className="form-group col-lg-3 col-md-3 col-sm-3 col-xs-3">
                                        </div>
                                        <div className="form-group col-lg-3 col-md-3 col-sm-3 col-xs-3">
                                            <strong>Beneficial Owner 1</strong>
                                        </div>
                                        <div className="form-group col-lg-3 col-md-3 col-sm-3 col-xs-3">
                                            <strong>Beneficial Owner 2</strong>
                                        </div>
                                        <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                                            <strong>Beneficial Owner 3</strong>
                                        </div>
                                    </div>

                                    <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">Title (Mr/Mrs)</label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Title (Mr/Mrs)"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Title (Mr/Mrs)"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Title (Mr/Mrs)"/>
                                        </div>
                                    </div>

                                    <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">Full name/ Legal name</label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Full name/ Legal name"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Full name/ Legal name"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Full name/ Legal name"/>
                                        </div>
                                    </div>

                                    {/* <div className="form-group row d-none">
                                        <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3 bg-primar">
                                            <label className="form-check-label" for="inlineCheckbox1">Ownership</label>
                                        </div>
                                        <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3  bg-warnin">
                                            <input className="form-check-input" onChange = {inputEvent} type="checkbox" id="inlineCheckbox2" value="option2" />
                                            <label className="form-check-label"  for="inlineCheckbox2">Direct Ownership</label>
                                        </div>
                                        <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3  bg-dange">
                                            <input className="form-check-input" onChange = {inputEvent} type="checkbox" id="inlineCheckbox2" value="option2" />
                                            <label className="form-check-label" for="inlineCheckbox2">Direct Ownership</label>
                                        </div>
                                        <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3  bg-succes">
                                            <input className="form-check-input" onChange = {inputEvent} type="checkbox" id="inlineCheckbox2" value="option2" />
                                            <label className="form-check-label" for="inlineCheckbox2">Direct Ownership</label>
                                        </div>
                                    </div> */}

                                    <div class="form-group row">
                                        <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                                            <div class="form-check-inline">
                                            <label class="form-check-label" for="check2">
                                                Ownership
                                            </label>
                                            </div>
                                        </div>

                                        <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                                            <div className="form-check-inline">
                                                <label className="form-check-label" for="check2">
                                                    <input type="checkbox" className="form-check-input" onChange = {inputEvent} id="check2" name="vehicle2" value="something" />Direct Ownership
                                                </label>
                                            </div>

                                            <div className="form-check-inline">
                                                <label className="form-check-label" for="check2">
                                                    <input type="checkbox" className="form-check-input" onChange = {inputEvent} id="check2" name="vehicle2" value="something" />Indirect Ownership
                                                </label>
                                            </div>  
                                        </div>
                                        <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                                            <div className="form-check-inline">
                                                <label className="form-check-label" for="check2">
                                                    <input type="checkbox" className="form-check-input" onChange = {inputEvent} id="check2" name="vehicle2" value="something" />Direct Ownership
                                                </label>
                                            </div>
                                            <div className="form-check-inline">
                                                <label className="form-check-label" for="check2">
                                                    <input type="checkbox" className="form-check-input" onChange = {inputEvent} id="check2" name="vehicle2" value="something" />Indirect Ownership
                                                </label>
                                            </div>
                                        </div>
                                        <div className="col-lg-3 col-md-3 col-sm-3 col-xs-3">
                                            <div className="form-check-inline">
                                                <label className="form-check-label" for="check2">
                                                    <input type="checkbox" className="form-check-input" onChange = {inputEvent} id="check2" name="vehicle2" value="something" />Direct Ownership
                                                </label>
                                            </div>
                                            <div className="form-check-inline">
                                                <label className="form-check-label" for="check2">
                                                    <input type="checkbox" className="form-check-input" onChange = {inputEvent} id="check2" name="vehicle2" value="something" />Indirect Ownership
                                                </label>
                                            </div>
                                        </div>
                                    </div>

                                     <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">% ownership</label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="% ownership"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="% ownership"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="% ownership"/>
                                        </div>
                                    </div>
                                     <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">ID Document number </label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="ID Document number "/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="ID Document number "/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="ID Document number "/>
                                        </div>
                                    </div>
                                     <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">D Document type</label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="ID Document type"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="ID Document type"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="ID Document type"/>
                                        </div>
                                    </div>
                                     <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">Phone number</label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Phone number"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Phone number"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Phone number"/>
                                        </div>
                                    </div>
                                    <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">Email address </label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent}  placeholder="Email address "/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Email address "/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Email address "/>
                                        </div>
                                    </div>
                                     <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">Current home address</label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Current home address"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Current home address"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Current home address"/>
                                        </div>
                                    </div>
                                     <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">Postcode</label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Postcode"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Postcode"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Postcode"/>
                                        </div>
                                    </div>
                                    <div className ="form-group row">
                                        <label for="colFormLabel" className ="col-sm-3 col-form-label">City</label>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="City"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="City"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="City"/>
                                        </div>
                                    </div>
                                    <div className ="form-group row">
                                        <label for="colFormLabel" className ="col-sm-3 col-form-label">Country</label>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Country"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Country"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Country"/>
                                        </div>
                                    </div>
                                    <div className ="form-group row">
                                        <label for="colFormLabel" className ="col-sm-3 col-form-label">Nationality (Only applicable for individuals ) </label>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Nationality "/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Nationality "/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Nationality "/>
                                        </div>
                                    </div>
                                    <div className ="form-group row">
                                        <label for="colFormLabel" className ="col-sm-3 col-form-label"> Company registration number (Only applicable for corporations )</label>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Company registration number"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Company registration number"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Company registration number"/>
                                        </div>
                                    </div>
                                    <div className ="form-group row">
                                        <label for="colFormLabel" className ="col-sm-3 col-form-label">Country</label>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Country"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Country"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" id="colFormLabel" onChange = {inputEvent} placeholder="Country"/>
                                        </div>
                                    </div>
                                    <div className ="form-group">
                                        <div className= "row">
                                            <label for="typeofbusiness" className="col-sm-3"> Is the beneficial owner a Director/Authorised signatory? (Email address required for electronic signature)</label><br/>
                                            <div className ="col-sm-3">
                                                <div class="form-check-inline">
                                                    <label class="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div class="form-check-inline">
                                                    <label class="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" id="radio2" name="optradio" value="option2"/>No
                                                    </label>
                                                </div>
                                            </div>
                                            <div className ="col-sm-3">
                                                <div class="form-check-inline">
                                                    <label class="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div class="form-check-inline">
                                                    <label class="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" id="radio2" name="optradio" value="option2"/>No
                                                    </label>
                                                </div>
                                            </div>
                                            <div className ="col-sm-3">
                                                <div class="form-check-inline">
                                                    <label class="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div class="form-check-inline">
                                                    <label class="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" id="radio2" name="optradio" value="option2"/>No
                                                    </label>
                                                </div>
                                            </div>
                                        </div>   
                                    </div>
                                </div>
                                </div>
                                
                                <div class="merchant-application">
                                </div>

                                <div className="col-11 mx-auto">
                                <div className ="Beneficial">
                                    <strong>Director / Authorised Signatory</strong>
                                    <div className ="form-row">
                                        <div className ="form-group col-md-3">
                                        </div>
                                        <div className ="form-group col-md-3">
                                            <strong>Director / Authorised Signatory 1</strong>
                                        </div>
                                        <div className ="form-group col-md-3">
                                            <strong>Director / Authorised Signatory 2</strong>
                                        </div>
                                        <div className ="form-group col-md-3">
                                            <strong>Director / Authorised Signatory 3</strong>
                                        </div>
                                    </div>

                                    <div className ="form-group row">
                                        <label for="colFormLabel" className ="col-sm-3 col-form-label">Full Name</label>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Full Name"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Full Name"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Full Name"/>
                                        </div>
                                    </div>

                                    <div className ="form-group row">
                                        <label for="colFormLabel" className ="col-sm-3 col-form-label">ID Document Number </label>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="ID Document Number"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="ID Document Number"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="ID Document Number"/>
                                        </div>
                                    </div>
                                    <div className ="form-group row">
                                        <label for="colFormLabel" className ="col-sm-3 col-form-label">ID Document type </label>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="ID Document Type"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="ID Document Type"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="text" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="ID Document Type"/>
                                        </div>
                                    </div>

                                     <div className ="form-group row">
                                        <label for="colFormLabel" className ="col-sm-3 col-form-label">Email address (Email address required for electronic signature)</label>
                                        <div className ="col-sm-3">
                                            <input type="email" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Email address"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="email" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Email address"/>
                                        </div>
                                        <div className ="col-sm-3">
                                            <input type="email" className ="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Email address"/>
                                        </div>
                                    </div>

                                     <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">Phone number </label>
                                        <div className="col-sm-3">
                                            <input type="number" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Phone number"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="number" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Phone number"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="number" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Phone number"/>
                                        </div>
                                    </div>
                                     <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">Current Home Address</label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Current home address"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Current home address"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Current home address"/>
                                        </div>
                                    </div>
                                     <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">Postcode</label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Postcode"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Postcode"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Postcode"/>
                                        </div>
                                    </div>

                                    <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">City  </label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="City  "/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="City  "/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="City  "/>
                                        </div>
                                    </div>
                                     <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">Country</label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Country"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Country"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Country"/>
                                        </div>
                                    </div>
                                     <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-3 col-form-label">Nationality (Only applicable for individuals )</label>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Nationality"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Nationality"/>
                                        </div>
                                        <div className="col-sm-3">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Nationality"/>
                                        </div>
                                    </div>
                                    <div className = "conditions">
                                        <strong>1 :  Fill a minimum of 2 directors, do not complete if at least 2 beneficial owners are also directors </strong>
                                    </div>
                                </div>
                                <div className="complementary">
                                    <strong>Complementary information</strong>
                                    <div className="form-group">
                                        <div className="form-row">
                                            <div className="col-sm-6">
                                                <label for="typeofbusiness"> Does your company fulfil orders directly? </label><br/>
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio1">
                                                        <input type="radio" className="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio2">
                                                        <input type="radio" className="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                                    </label>
                                                </div>
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio2">
                                                        <input type="radio" className="form-check-input" onChange = {inputEvent} id="radio3" name="optradio" value="option3" />N/A (Non applicable)
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="col-sm-6">
                                                <label for="information"> If no, please provide fulfilment information details </label><br/>
                                                <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder=""/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <div className="form-row">
                                            <div className="col-sm-6">
                                                <label for="typeofbusiness"> Does your company operate affiliate programs? </label><br/>
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio1">
                                                        <input type="radio" className="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio2">
                                                        <input type="radio" className="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="col-sm-6">
                                                <label for="information"> If yes, please provide details of your affiliate programme  </label><br/>
                                                <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder=""/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-12 col-form-label">Name of previous/current processor(s) and/or acquirers(s)</label>
                                        <div className="col-sm-12">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Country"/>
                                        </div>
                                    </div>
                                    <div className="form-group row">
                                        <label for="colFormLabel" className="col-sm-12 col-form-label">Reason for applying to Openacquiring.com</label>
                                        <div className="col-sm-12">
                                            <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="Reason for applying"/>
                                        </div>
                                    </div>
                                </div>
                                </div>
                                
                                <div class="merchant-application">
                                </div>

                                <div className="col-11 mx-auto">
                                <div className = "website">
                                    <h2 className="text-center m-4">Website Compliance</h2>
                                </div>
                                <div className="form-group">
                                    <div className="form-row">
                                        <div className="col-sm-8">
                                            <label for="typeofbusiness"> Is your website PC/DSS compliant or are you using the services of a PCIcompliant host?  </label><br/>
                                        </div>
                                        <div className="col-sm-4">
                                            <div className="form-check-inline">
                                                <label className="form-check-label" for="radio1">
                                                    <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                                </label>
                                            </div>
                                            <div class="form-check-inline">
                                                <label className="form-check-label" for="radio2">
                                                    <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="form-group row">
                                    <div className="col-sm-4">
                                        <label for="colFormLabel" className="col-form-label">If yes, please list host/IPs</label>
                                    </div>
                                    <div className="col-sm-8">
                                        <input type="text" className="form-control" onChange = {inputEvent} id="colFormLabel" placeholder="If yes, please list host/IPs"/>
                                    </div>
                                </div>
                                <div className="form-group row">
                                    <label for="colFormLabel" className="col-sm-12 col-form-label">What fraud prevention techniques do you use (e.g., list of black listed countries, velocity </label>
                                    <div className="col-sm-12">
                                        <input type="text" className="form-control"  onChange = {inputEvent} id="colFormLabel" placeholder="What fraud prevention techniques do you use (e.g., list of black listed countries, velocity "/>
                                    </div>
                                </div>

                                <div className="application">
                                    <strong>Please check, if applicable to your website:</strong>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" value="" onChange = {inputEvent} id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">Detailed descriptions of the goods/services 
                                        being offered are available, and prices of goods/services are clearly displayed 
                                        </label>
                                    </div>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" value="" onChange = {inputEvent} id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">The company address(es) is/are clearly displayed
                                        </label>
                                    </div>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" value="" onChange = {inputEvent} id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">The privacy policy is clearly displayed  
                                        </label>
                                    </div>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" value="" onChange = {inputEvent} id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">Terms and conditions are clearly displayed 
                                        </label>
                                    </div>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" value="" onChange = {inputEvent} id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">The return, refund and cancellation policies are clearly displayed 
                                        </label>
                                    </div>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" value="" onChange = {inputEvent} id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">The delivery policy (including export restrictions), the shipping options, timeline of delivery and fees are clearly displayed 
                                        </label>
                                    </div>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" value="" onChange = {inputEvent} id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">A confirmation email receipt is sent to cardholder when the product is fulfilled
                                        </label>
                                    </div>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" value="" onChange = {inputEvent} id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">Transaction currencies are clearly displayed 
                                        </label>
                                    </div>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" value="" onChange = {inputEvent} id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">The card schemes logo/ trademarks are clearly displayed
                                        </label>
                                    </div>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" value="" onChange = {inputEvent} id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">The website is TLS secure 
                                        </label>
                                    </div>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" value="" onChange = {inputEvent} id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">The website owner controls the site content, as well as the delivery of services offered 
                                        </label>
                                    </div>
                                </div>
                                </div>
                                
                                <div class="merchant-application">
                                </div>

                                <div className="col-11 mx-auto">
                                <div className = "Services">
                                    <h2 className="text-center m-4">Services Required</h2>
                                </div>
                                <div className="credit">
                                    <strong>Credit Card Brands</strong>
                                        <div className="form-group">
                                        
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox1" value="option1"/>
                                            <label class="form-check-label" for="inlineCheckbox1">Visa </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox3" value="option2"/>
                                            <label class="form-check-label" for="inlineCheckbox3">Mastercard </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox3" value="option3"/>
                                            <label class="form-check-label" for="inlineCheckbox3">American Express </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox3" value="option4"/>
                                            <label class="form-check-label" for="inlineCheckbox3">Diners/Discover</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox3" value="option5"/>
                                            <label class="form-check-label" for="inlineCheckbox3">JCB </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox3" value="option6"/>
                                            <label class="form-check-label" for="inlineCheckbox3">UnionPay</label>
                                        </div>
                                    </div>        
                                </div>
                                
                                <div className="form-group row">
                                    <label for="colFormLabel" className="col-sm-12 col-form-label">Processing currencies</label>
                                    <div className="col-sm-12">
                                        <input type="text" className="form-control processing" id="colFormLabel" onChange = {inputEvent} placeholder="Processing currencies"/>
                                        <input type="text" className="form-control processing" id="colFormLabel" onChange = {inputEvent} placeholder="Processing currencies"/>
                                    </div>
                                </div>
                                <div className="service">
                                    <strong>Services required from Openacquiring.com</strong>
                                </div>
                                <div className="form-group">
                                        <div className="form-row">
                                            <div className="col-sm-8">
                                                <label for="typeofbusiness"> Local payments (e.g., eNETS, iDEAL, Webmoney, QIWI, Sofort, etc...)  </label><br/>
                                            </div>
                                            <div className="col-sm-4">
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div class="form-check-inline">
                                                    <label className="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <div className="form-row">
                                            <div className="col-sm-8">
                                                <label for="typeofbusiness">Recurring billing </label><br/>
                                            </div>
                                            <div className="col-sm-4">
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div class="form-check-inline">
                                                    <label className="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <div className="form-row">
                                            <div className="col-sm-8">
                                                <label for="typeofbusiness"> Tokenisation  </label><br/>
                                            </div>
                                            <div className="col-sm-4">
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div class="form-check-inline">
                                                    <label className="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="form-group">
                                        <div className="form-row">
                                            <div className="col-sm-8">
                                                <label for="typeofbusiness"> 3D Secure  </label><br/>
                                            </div>
                                            <div className="col-sm-4">
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" onChange = {inputEvent} for="radio1">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div class="form-check-inline">
                                                    <label className="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                     <div className="form-group">
                                        <div className="form-row">
                                            <div className="col-sm-8">
                                                <label for="typeofbusiness"> Risk/fraud management  </label><br/>
                                            </div>
                                            <div className="col-sm-4">
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div class="form-check-inline">
                                                    <label className="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                     <div className="form-group">
                                        <div className="form-row">
                                            <div className="col-sm-8">
                                                <label for="typeofbusiness"> Checkkout.js</label><br/>
                                            </div>
                                            <div className="col-sm-4">
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div class="form-check-inline">
                                                    <label className="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                     <div className="form-group">
                                        <div className="form-row">
                                            <div className="col-sm-8">
                                                <label for="typeofbusiness"> CheckoutKit.js  </label><br/>
                                            </div>
                                            <div className="col-sm-4">
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div class="form-check-inline">
                                                    <label className="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                     <div className="form-group">
                                        <div className="form-row">
                                            <div className="col-sm-8">
                                                <label for="typeofbusiness"> Merchant API (Server to Server)  </label><br/>
                                            </div>
                                            <div className="col-sm-4">
                                                <div className="form-check-inline">
                                                    <label className="form-check-label" for="radio1">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio1" name="optradio" value="option1" checked />Yes
                                                    </label>
                                                </div>
                                                <div class="form-check-inline">
                                                    <label className="form-check-label" for="radio2">
                                                        <input type="radio" class="form-check-input" onChange = {inputEvent} id="radio2" name="optradio" value="option2" />No
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="shopping">
                                        <strong> Shopping cart / Software plug-in </strong>
                                    </div>
                                    <div className="form-group">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox1" value="option1"/>
                                            <label class="form-check-label" for="inlineCheckbox1">Do not use </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox3" value="option2"/>
                                            <label class="form-check-label" for="inlineCheckbox3">CS-Cart </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox3" value="option3"/>
                                            <label class="form-check-label" for="inlineCheckbox3">ZenCart </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox3" value="option4"/>
                                            <label class="form-check-label" for="inlineCheckbox3">osCommerce </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox3" value="option5"/>
                                            <label class="form-check-label" for="inlineCheckbox3">Magento  </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox3" value="option6"/>
                                            <label class="form-check-label" for="inlineCheckbox3">osCMax </label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" onChange = {inputEvent}  id="inlineCheckbox3" value="option7"/>
                                            <label class="form-check-label" for="inlineCheckbox3">Prestashop </label>
                                        </div>
                                    </div>
                                    <div className="Bank_Account">
                                    <div className="form">
                                        <div className="row m-1">
                                            <div className="form-group col-md-3">
                                                <input class="form-check-input" type="checkbox" onChange = {inputEvent} id="inlineCheckbox3" value="option7"/>
                                                <label class="form-check-label" for="inlineCheckbox3">Other </label>
                                            </div>
                                            <div className="form-group col-md-9">
                                                <input type="text" className="form-control" onChange = {inputEvent} id="inputZip" placeholder="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>            
                                </div>
                                
                                <div class="merchant-application">
                                </div>        
                                <div className="col-11 mx-auto">
                                <div className = "documents">
                                    <h2 className="text-center m-4">Checklist Of Required Documents</h2>
                                </div>
                                <div className="form-group">
                                    <p>Please provide a copy* of the following documents:</p>
                                </div>
                                <div className="application">
                                    <strong>Incorporation documents issued by the Company Registrar:</strong>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" onChange = {inputEvent} value="" id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault">Certificate of Incorporation for the Dpplying Company (or equivalent1)
                                        </label>
                                    </div>
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" onChange = {inputEvent} value="" id="flexCheckDefault"/>
                                        <label className="form-check-label" for="flexCheckDefault"> List of Directors (if not in one of the documents above)
                                        </label>
                                    </div>
                                    <div className="open_document">
                                        <strong>Operating documents</strong>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" onChange = {inputEvent} value="" id="flexCheckDefault"/>
                                            <label className="form-check-label" for="flexCheckDefault">Copy of any trading/business license (if applicable - e.g Gaming, Securities Brokerage) of the Dpplying Company  
                                            </label>
                                        </div>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" onChange = {inputEvent} value="" id="flexCheckDefault"/>
                                            <label className="form-check-label" for="flexCheckDefault">if applicable, Proof of PCI compliance documents (PCI self-assessment questionnaire Attestation of Compliance, Quarterly scan result)
                                            </label>
                                        </div>
                                    </div>
                                    <div className="open_document">
                                        <strong>Operating documents</strong>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" onChange = {inputEvent} value="" id="flexCheckDefault"/>
                                            <label className="form-check-label" for="flexCheckDefault">Copy of any trading/business license (if applicable - e.g Gaming, Securities Brokerage) of the Dpplying Company  
                                            </label>
                                        </div>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" onChange = {inputEvent} value="" id="flexCheckDefault"/>
                                            <label className="form-check-label" for="flexCheckDefault">if applicable, Proof of PCI compliance documents (PCI self-assessment questionnaire Attestation of Compliance, Quarterly scan result)
                                            </label>
                                        </div>
                                    </div>
                                    <div className="open_document">
                                        <strong>Personal information of Directors/Authorised signatories and Beneficial owner of the Dpplying Company</strong>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" onChange = {inputEvent} value="" id="flexCheckDefault"/>
                                            <label className="form-check-label" for="flexCheckDefault">Passpott/ID Documnet(original certified copy)
                                            </label>
                                        </div>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" onChange = {inputEvent} value="" id="flexCheckDefault"/>
                                            <label className="form-check-label" for="flexCheckDefault">Proof of personal address less than three months old (e.g... utility bill, personal bank statement a credit card statement)
                                            </label>
                                        </div>
                                    </div>
                                    <div className="open_document">
                                        <strong>Processing history</strong>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" onChange = {inputEvent} value="" id="flexCheckDefault"/>
                                            <label className="form-check-label" for="flexCheckDefault">Last 6-months processing statement of the applying Company including monthly sales, chargebacks, refunds, and number of transactions
                                            </label>
                                        </div>
                                    </div>
                                    <div className="open_document">
                                        <strong>Financial </strong>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" onChange = {inputEvent} value="" id="flexCheckDefault"/>
                                            <label className="form-check-label" for="flexCheckDefault">Most recent audited financial statements (if operating for a minimum of 1 year) 
                                            </label>
                                        </div>
                                        <div className="form-check">
                                            <input className="form-check-input" type="checkbox" onChange = {inputEvent} value="" id="flexCheckDefault"/>
                                            <label className="form-check-label" for="flexCheckDefault">Company bak account statement (confirming the Merchant bank account information provided in Schedule 2 of the Merchant  Service Agreement) Schedule 
                                            </label>
                                        </div>
                                    </div>
                                    <div className="electronic">
                                        <h4>* Electronic copy sufficient (digital scan or print screen) </h4>            
                                    </div>
                                    <div className="term">
                                        <p>1. Can include: Government Trade Licence (Dubai), Sole Trader Licence (India), Municipal Corporation Licence (India), Biz file (Singapore), etc</p>
                                        <p>2. Can include: Shareholder register, Evidence of ownership listed in Trade Licence (Dubai), Evidence of ownership listed is Sole Trader Licence (India), Biz file (Singapore), etc..</p>
                                    </div>
                                    <hr/>
                                    <div className="risk">
                                        <p>The individual signing this Merchant Application Form certifies, that all the information and documentation submitted in connection with this application form is correct and complete and (ii) undertakes to inform us immediately in case of any material changes to the information or documentation provided and this in particular in case of any changes of Owners/Shareholders, or Ultimate Beneficial Owners.</p>
                                    </div>
                                </div>
                                    <button type="submit" className="btn btn-primary" onClick={onSubmits} style={{margin:"20px", marginLeft: "50%"}} >Submit</button>
                                </div>
                                
                            </form>
                    </div>
                </div>
            </section>
            <Footer/>
        </>
    );   
}
export default Merchant_Form